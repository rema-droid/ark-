import React from 'react';
import { ZoneData } from '../types';

interface InfoPanelProps {
  zone: ZoneData | null;
  onClose: () => void;
  onSelect: (zone: ZoneData) => void;
}

const InfoPanel: React.FC<InfoPanelProps> = ({ zone, onClose, onSelect }) => {
  return (
    <div
      className={`fixed top-0 right-0 h-full w-full md:w-96 bg-surface-container/90 backdrop-blur-md shadow-2xl z-40 transform transition-transform duration-500 ease-in-out ${
        zone ? 'translate-x-0' : 'translate-x-full'
      }`}
      aria-hidden={!zone}
    >
      <div className="p-6 text-on-surface h-full flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-primary">{zone?.name || 'Select a Zone'}</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-on-surface/10 transition-colors"
            aria-label="Close panel"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {zone && (
          <div className="flex-grow flex flex-col space-y-6">
            <div className="bg-surface-container-high p-4 rounded-xl">
              <h3 className="font-semibold text-lg mb-2">Zone Statistics</h3>
              <div className="flex items-center space-x-3">
                <span className="material-symbols-outlined text-secondary">group</span>
                <p>
                  <span className="font-bold text-xl">{zone.userCount.toLocaleString()}</span> Active Members
                </p>
              </div>
            </div>

            <div className="flex-grow border-t border-outline-variant pt-6">
                <h3 className="font-semibold text-lg mb-4 text-center">Community Hub</h3>
                <div className="space-y-4">
                    <FeatureButton icon="favorite" text="Interactive Prayer Wall" />
                    <FeatureButton icon="public" text="Mission Projects" />
                    <FeatureButton icon="videocam" text="Live Q&A with Leadership" />
                </div>
            </div>

            <button 
              onClick={() => onSelect(zone)}
              className="w-full bg-primary hover:bg-primary/90 text-on-primary font-bold py-3 px-4 rounded-full transition-colors duration-200 mt-auto"
            >
                View Zone Details
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

interface FeatureButtonProps {
    icon: string;
    text: string;
}

const FeatureButton: React.FC<FeatureButtonProps> = ({icon, text}) => (
    <button className="w-full flex items-center space-x-4 p-4 bg-surface-container-high rounded-xl hover:bg-surface-container-highest transition-colors duration-200 text-left">
        <span className="material-symbols-outlined text-secondary">{icon}</span>
        <span className="font-medium">{text}</span>
    </button>
)

export default InfoPanel;