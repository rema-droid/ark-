import React from 'react';

type ViewMode = 'globe' | 'directory' | 'events' | 'transmissions' | 'agentProfile';

interface BottomNavBarProps {
  currentView: ViewMode;
  onSwitchView: (view: ViewMode) => void;
}

const NavItem: React.FC<{
    icon: string;
    label: string;
    isActive: boolean;
    onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => (
  <button 
    onClick={onClick} 
    className="flex flex-col items-center justify-center flex-1 h-full pt-2 pb-1 transition-colors duration-200"
    aria-pressed={isActive}
    >
    <div className={`relative flex items-center justify-center w-16 h-8`}>
        <div className={`absolute inset-0 rounded-full transition-colors ${isActive ? 'bg-secondary-container' : ''}`}></div>
        <span className={`material-symbols-outlined transition-colors z-10 ${isActive ? 'text-on-secondary-container' : 'text-on-surface-variant'}`}>{icon}</span>
    </div>
    <span className={`mt-1 text-xs font-medium transition-colors ${isActive ? 'text-on-surface' : 'text-on-surface-variant'}`}>{label}</span>
  </button>
);

const BottomNavBar: React.FC<BottomNavBarProps> = ({ currentView, onSwitchView }) => {
  const views: Exclude<ViewMode, 'agentProfile'>[] = ['globe', 'directory', 'events', 'transmissions'];
  const icons: { [key in typeof views[number]]: string } = {
    globe: 'public',
    directory: 'list_alt',
    events: 'event',
    transmissions: 'rss_feed'
  };
   const labels: { [key in typeof views[number]]: string } = {
    globe: 'Globe',
    directory: 'Directory',
    events: 'Events',
    transmissions: 'Transmissions'
  };


  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 h-20 bg-surface-container/90 backdrop-blur-lg border-t border-outline-variant md:bottom-4 md:left-1/2 md:-translate-x-1/2 md:w-auto md:h-auto md:border-none md:rounded-2xl md:shadow-lg">
      <div className="flex justify-around items-stretch h-full md:gap-x-1 md:p-1">
        {views.map((view) => (
             <NavItem 
                key={view}
                icon={icons[view]} 
                label={labels[view]} 
                isActive={currentView === view} 
                onClick={() => onSwitchView(view)} 
             />
        ))}
      </div>
    </nav>
  );
};

export default BottomNavBar;