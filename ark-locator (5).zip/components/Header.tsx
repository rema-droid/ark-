import React from 'react';

interface HeaderProps {
    onShowAgentProfile: () => void;
}

const Header: React.FC<HeaderProps> = ({ onShowAgentProfile }) => {
  return (
    <header className="sticky top-0 left-0 right-0 z-30 p-4 bg-surface/80 backdrop-blur-lg h-[72px]">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-xl md:text-2xl font-bold text-on-surface tracking-wider">
          <span className="text-primary">Ark</span> Locator
        </h1>
        <button 
          onClick={onShowAgentProfile}
          className="w-10 h-10 flex items-center justify-center rounded-full text-on-surface hover:bg-on-surface/10 transition-colors"
          aria-label="View Agent Profile"
        >
          <span className="material-symbols-outlined">admin_panel_settings</span>
        </button>
      </div>
    </header>
  );
};

export default Header;