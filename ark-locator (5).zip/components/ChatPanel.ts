import { LitElement, html, css, nothing } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { GoogleGenAI, Chat, FunctionCall, GenerateContentResponse, Part, Type, GroundingChunk } from '@google/genai';
import { ZONES_DATA } from '../constants.ts';
import { Message } from '../types.ts';

@customElement('chat-panel')
export class ChatPanel extends LitElement {
  @property({ type: String, reflect: true })
  isopen = "false";

  @state()
  private messages: Message[] = [];

  @state()
  private isLoading = false;

  @query('#chat-input')
  private chatInput!: HTMLInputElement;

  @query('#messages-container')
  private messagesContainer!: HTMLDivElement;

  private chat: Chat | null = null;

  constructor() {
    super();
    this.initializeAi();
  }

  private async initializeAi() {
    if (!process.env.API_KEY) {
      console.error("API_KEY environment variable not set.");
      this.messages = [{ role: 'model', text: 'Configuration error: API Key is missing. Please contact support.' }];
      return;
    }

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const tools = [
      { googleSearch: {} },
      {
        functionDeclarations: [
          {
            name: 'findAndZoomToZone',
            description: 'Finds a zone by name or location and zooms the globe view to it.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                zoneName: {
                  type: Type.STRING,
                  description: 'The name or location of the zone to find and zoom to. E.g., "Lagos", "Abuja", "Dallas, USA".',
                },
              },
              required: ['zoneName'],
            },
          },
          {
            name: 'getBishopricZoneAddresses',
            description: 'Get all church addresses, locations, and leaders in the Bishopric zones.',
            parameters: {
              type: Type.OBJECT,
              properties: {}
            },
          },
          {
            name: 'getZoneSummary',
            description: 'Gets a summary of a specific zone, including its leader, location, member count, and events.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                zoneName: {
                  type: Type.STRING,
                  description: 'The name of the zone to summarize. E.g., "BISHOPRIC - LAGOS"',
                },
              },
              required: ['zoneName'],
            },
          }
        ],
      }
    ];

    this.chat = ai.chats.create({
      model: 'gemini-2.5-flash-preview-04-17',
      config: {
        systemInstruction: 'You are a helpful assistant for the Ark Locator app. You can help users find information about church zones, and you can access up-to-date information from Google Search for general queries. You can also interact with the map to find and zoom to locations. Be friendly and concise.',
        tools: tools
      }
    });

    this.messages = [{ role: 'model', text: "Hello! How can I help you? Try asking 'Show me the church in Japan' or 'What is the latest news about CGMi?'" }];
  }
  
  private async getZoneSummary({ zoneName }: { zoneName: string }) {
     const zone = ZONES_DATA.find(z =>
      z.name.toLowerCase().includes(zoneName.toLowerCase()) ||
      z.location.toLowerCase().includes(zoneName.toLowerCase())
    );

    if (zone) {
      return {
        name: zone.name,
        leader: zone.leader,
        location: zone.location,
        userCount: zone.userCount,
        events: zone.events.map(e => e.title).join(', '),
      }
    } else {
       return { error: `Could not find a zone matching "${zoneName}".` };
    }
  }

  private async findAndZoomToZone({ zoneName }: { zoneName: string }) {
    const zone = ZONES_DATA.find(z =>
      z.name.toLowerCase().includes(zoneName.toLowerCase()) ||
      z.location.toLowerCase().includes(zoneName.toLowerCase())
    );
    if (zone) {
      this.dispatchEvent(new CustomEvent('zoom-to-zone', {
        detail: zone,
        bubbles: true,
        composed: true
      }));
      return { success: true, message: `Found and zoomed to ${zone.name}.` };
    } else {
      return { success: false, message: `Could not find a zone matching "${zoneName}".` };
    }
  };

  private async getBishopricZoneAddresses() {
    const bishopricZones = ZONES_DATA.filter(zone =>
      zone.name.toLowerCase().includes('bishopric')
    );
    const addresses = bishopricZones.map(zone => ({
      name: zone.name,
      location: zone.location,
      leader: zone.leader,
    }));
    return { addresses };
  };

  private async executeFunctionCall(functionCall: FunctionCall) {
    const { name, args } = functionCall;
    switch (name) {
      case 'findAndZoomToZone':
        return this.findAndZoomToZone(args as { zoneName: string });
      case 'getBishopricZoneAddresses':
        return this.getBishopricZoneAddresses();
      case 'getZoneSummary':
        return this.getZoneSummary(args as { zoneName: string });
      default:
        // This should not happen if the model is working correctly
        return { error: `Unknown function call: ${name}` };
    }
  }

  protected updated(changedProperties: Map<PropertyKey, unknown>): void {
    if (changedProperties.has('messages')) {
      this.scrollToBottom();
    }
  }

  private scrollToBottom() {
    this.messagesContainer?.scrollTo({ top: this.messagesContainer.scrollHeight, behavior: 'smooth' });
  }

  private async handleSendMessage() {
    const userInput = this.chatInput.value.trim();
    if (!userInput || this.isLoading || !this.chat) return;

    this.messages = [...this.messages, { role: 'user', text: userInput }];
    this.isLoading = true;
    this.chatInput.value = '';
    
    try {
      let response: GenerateContentResponse = await this.chat.sendMessage({ message: userInput });

      while (response.functionCalls && response.functionCalls.length > 0) {
        const toolExecutionResults: Part[] = await Promise.all(
          response.functionCalls.map(async (call) => {
            const result = await this.executeFunctionCall(call);
            return {
              functionResponse: {
                name: call.name,
                response: result,
              },
            };
          })
        );

        response = await this.chat.sendMessage({ message: toolExecutionResults });
      }
      
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources = groundingChunks
          ?.map((chunk: GroundingChunk) => chunk.web)
          .filter((web): web is { uri: string; title: string } => !!web?.uri)
          .reduce((acc, web) => { // De-duplicate sources
              if (!acc.some(s => s.uri === web.uri)) {
                  acc.push(web);
              }
              return acc;
          }, [] as { uri: string; title: string }[]);

      this.messages = [...this.messages, { role: 'model', text: response.text, sources }];
    } catch (error) {
      console.error("Error sending message:", error);
      this.messages = [...this.messages, { role: 'model', text: "Sorry, I encountered an error. Please try again." }];
    } finally {
      this.isLoading = false;
    }
  }

  private handleKeyPress(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      this.handleSendMessage();
    }
  }

  private requestClose() {
    this.dispatchEvent(new CustomEvent('close-requested', { bubbles: true, composed: true }));
  }

  static styles = css`
    :host {
      --primary: #a4c8ff;
      --on-primary: #00315e;
      --primary-container: #004885;
      --on-primary-container: #d4e3ff;
      --secondary: #bdc7d8;
      --on-secondary: #283141;
      --secondary-container: #3e4758;
      --on-secondary-container: #d9e3f5;
      --surface: #131416;
      --surface-container: #202022;
      --surface-container-high: #2a2b2d;
      --surface-container-highest: #353638;
      --on-surface: #e3e2e6;
      --on-surface-variant: #c3c6cf;
      --outline: #8d9199;
      --outline-variant: #43474e;
      font-family: 'Roboto', sans-serif;
    }

    .panel-container {
      position: fixed;
      top: 0;
      right: 0;
      height: 100%;
      width: clamp(320px, 30vw, 420px);
      background-color: rgba(32, 32, 34, 0.8);
      backdrop-filter: blur(10px);
      box-shadow: -10px 0 20px rgba(0,0,0,0.2);
      z-index: 40;
      transform: translateX(100%);
      transition: transform 0.5s cubic-bezier(0.23, 1, 0.32, 1);
      display: flex;
      flex-direction: column;
      color: var(--on-surface);
      border-left: 1px solid var(--outline-variant);
    }
    
    @media (max-width: 640px) {
      .panel-container {
        width: 100vw;
        border-left: none;
      }
    }

    :host([isopen="true"]) .panel-container {
      transform: translateX(0);
    }

    .panel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      border-bottom: 1px solid var(--outline-variant);
      flex-shrink: 0;
    }

    .panel-title {
      font-size: 1.5rem;
      font-weight: bold;
      color: var(--primary);
    }

    .close-button {
      background: none;
      border: none;
      color: var(--on-surface-variant);
      cursor: pointer;
      width: 44px;
      height: 44px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 9999px;
      transition: background-color 0.2s, color 0.2s;
    }
    .close-button:hover {
      background-color: var(--on-surface-variant);
      color: var(--surface-container);
    }

    .messages-container {
      flex-grow: 1;
      overflow-y: auto;
      padding: 1.5rem;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .message-bubble {
        padding: 0.75rem 1rem;
        border-radius: 1.25rem;
        max-width: 85%;
        line-height: 1.5;
        word-wrap: break-word;
    }

    .user-message {
        background-color: var(--primary-container);
        color: var(--on-primary-container);
        align-self: flex-end;
        border-bottom-right-radius: 0.25rem;
    }

    .model-message {
        background-color: var(--surface-container-high);
        color: var(--on-surface);
        align-self: flex-start;
        border-bottom-left-radius: 0.25rem;
    }
    
    .loading-indicator {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .loading-indicator div {
        width: 0.5rem;
        height: 0.5rem;
        background-color: var(--on-surface-variant);
        border-radius: 50%;
        animation: pulse 1.4s infinite ease-in-out both;
    }
    
    .loading-indicator div:nth-child(1) { animation-delay: -0.32s; }
    .loading-indicator div:nth-child(2) { animation-delay: -0.16s; }
    
    @keyframes pulse {
        0%, 80%, 100% {
            transform: scale(0);
        }
        40% {
            transform: scale(1.0);
        }
    }

    .input-area {
        padding: 1rem;
        border-top: 1px solid var(--outline-variant);
        display: flex;
        gap: 0.5rem;
        background-color: var(--surface-container);
        flex-shrink: 0;
    }

    #chat-input {
        flex-grow: 1;
        background-color: var(--surface-container-high);
        border: 1px solid var(--outline);
        color: var(--on-surface);
        padding: 0.75rem 1.25rem;
        border-radius: 9999px;
        font-size: 1rem;
        transition: border-color 0.2s;
    }
    #chat-input:focus {
        outline: none;
        border-color: var(--primary);
    }

    .send-button {
        background-color: var(--primary);
        border: none;
        color: var(--on-primary);
        width: 3rem;
        height: 3rem;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background-color 0.2s;
        flex-shrink: 0;
    }
    .send-button:hover {
        background-color: var(--primary-container);
        color: var(--on-primary-container);
    }
    .send-button:disabled {
        background-color: var(--on-surface-variant);
        cursor: not-allowed;
    }
    
    .send-button .material-symbols-outlined {
        font-size: 24px;
        transition: transform 0.3s ease;
    }
    .send-button:hover .material-symbols-outlined {
        transform: rotate(90deg) scale(1.1);
    }
    
    .sources-container {
      margin-top: 0.75rem;
      padding-top: 0.75rem;
      border-top: 1px solid var(--surface-container-highest);
    }
    .sources-title {
      font-size: 0.8rem;
      font-weight: bold;
      color: var(--on-surface-variant);
      margin-bottom: 0.5rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .source-list {
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }
    .source-item {
      display: flex;
      align-items: flex-start;
      gap: 0.75rem;
      font-size: 0.875rem;
    }
    .source-link {
      color: var(--secondary);
      text-decoration: none;
      line-height: 1.4;
    }
    .source-link:hover {
      text-decoration: underline;
    }
    .source-icon {
        color: var(--outline);
        font-size: 18px;
        margin-top: 1px;
    }
  `;

  render() {
    return html`
      <div class="panel-container">
        <div class="panel-header">
          <h2 class="panel-title">AI Assistant</h2>
          <button @click=${this.requestClose} class="close-button" aria-label="Close chat panel">
             <span class="material-symbols-outlined">close</span>
          </button>
        </div>

        <div id="messages-container" class="messages-container">
            ${this.messages.map(msg => html`
                <div class="message-bubble ${msg.role}-message">
                    <div>${msg.text}</div>
                    ${msg.sources && msg.sources.length > 0 ? html`
                      <div class="sources-container">
                        <h3 class="sources-title">Sources</h3>
                        <div class="source-list">
                          ${msg.sources.map(source => html`
                            <div class="source-item">
                               <span class="material-symbols-outlined source-icon">link</span>
                               <a href=${source.uri} target="_blank" rel="noopener noreferrer" class="source-link">${source.title || source.uri}</a>
                            </div>
                          `)}
                        </div>
                      </div>
                    ` : nothing}
                </div>
            `)}
            ${this.isLoading ? html`
                <div class="message-bubble model-message">
                    <div class="loading-indicator">
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            ` : ''}
        </div>

        <div class="input-area">
          <input
            id="chat-input"
            type="text"
            placeholder="Ask me anything..."
            @keypress=${this.handleKeyPress}
            ?disabled=${this.isLoading}
          />
          <button class="send-button" @click=${this.handleSendMessage} ?disabled=${this.isLoading} aria-label="Send message">
            <span class="material-symbols-outlined">send</span>
          </button>
        </div>
      </div>
    `;
  }
}