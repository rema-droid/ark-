import React from 'react';
import { ZoneData } from '../types';

interface ZoneCardProps {
  zone: ZoneData;
  onSelect: () => void;
}

const ZoneCard: React.FC<ZoneCardProps> = ({ zone, onSelect }) => {
  return (
    <div 
      onClick={onSelect}
      className="bg-surface-container rounded-xl p-6 flex flex-col justify-between cursor-pointer border border-outline hover:bg-on-surface/[.08] transition-colors duration-300 ease-in-out h-full"
    >
      <div>
        <h3 className="text-xl font-bold text-primary mb-2 truncate">{zone.name}</h3>
        <p className="text-on-surface-variant mb-4 font-semibold truncate">{zone.leader}</p>
      </div>
      <div className="space-y-3 text-on-surface-variant">
        <div className="flex items-center space-x-2 text-sm">
            <span className="material-symbols-outlined w-4 h-4 flex-shrink-0 text-secondary">call</span>
            <span className="truncate">{zone.phone}</span>
        </div>
        <div className="flex items-center space-x-2 text-sm">
            <span className="material-symbols-outlined w-4 h-4 flex-shrink-0">location_on</span>
            <span className="truncate">{zone.location}</span>
        </div>
        <div className="flex items-center space-x-2 text-sm">
            <span className="material-symbols-outlined w-4 h-4 flex-shrink-0">group</span>
            <span>{zone.userCount.toLocaleString()} Members</span>
        </div>
      </div>
    </div>
  );
};

export default ZoneCard;