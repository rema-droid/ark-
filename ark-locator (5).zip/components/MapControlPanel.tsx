import React, { useMemo } from 'react';
import { ZONES_DATA } from '../constants';

interface MapControlPanelProps {
  isOpen: boolean;
  onClose: () => void;
  userLocation: { lat: number, lon: number } | null;
  onFindNearest: () => void;
  showUserLocation: boolean;
  onToggleUserLocation: () => void;
  showClouds: boolean;
  onToggleClouds: () => void;
  showMemberDensity: boolean;
  onToggleMemberDensity: () => void;
  activeRegion: string;
  onRegionChange: (region: string) => void;
}

const ToggleSwitch: React.FC<{
  checked: boolean,
  onChange: () => void,
  disabled?: boolean
}> = ({ checked, onChange, disabled }) => {
    return (
        <button
            type="button"
            className={`relative inline-flex items-center flex-shrink-0 h-8 w-14 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary focus:ring-offset-surface-container ${disabled ? 'cursor-not-allowed opacity-50' : ''} ${checked ? 'bg-primary' : 'bg-surface-container-highest'}`}
            role="switch"
            aria-checked={checked}
            onClick={disabled ? undefined : onChange}
            disabled={disabled}
        >
            <span
                aria-hidden="true"
                className={`${checked ? 'translate-x-6' : 'translate-x-0'} pointer-events-none inline-block h-6 w-6 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
            />
        </button>
    );
};

const MapControlPanel: React.FC<MapControlPanelProps> = ({
  isOpen, onClose, userLocation, onFindNearest,
  showUserLocation, onToggleUserLocation,
  showClouds, onToggleClouds,
  showMemberDensity, onToggleMemberDensity,
  activeRegion, onRegionChange
}) => {
  const regions = useMemo(() => ['all', ...Array.from(new Set(ZONES_DATA.map(z => z.region)))], []);

  return (
    <div
      className={`fixed top-0 right-0 h-full w-full md:w-80 bg-surface-container/90 backdrop-blur-md shadow-2xl z-40 transform transition-transform duration-500 ease-in-out ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
      aria-hidden={!isOpen}
    >
      <div className="p-6 text-on-surface h-full flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-secondary">Map Controls</h2>
          <button
            onClick={onClose}
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-on-surface/10 transition-colors"
            aria-label="Close map controls"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="flex-grow flex flex-col space-y-6">
            <div>
                <button 
                    onClick={onFindNearest}
                    disabled={!userLocation}
                    className="w-full flex items-center space-x-3 p-3 bg-secondary-container text-on-secondary-container rounded-xl hover:bg-secondary-container/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    <span className="material-symbols-outlined">my_location</span>
                    <span className="font-medium">Find Nearest Zone</span>
                </button>
            </div>
            
            <div className="border-t border-outline-variant pt-6 space-y-4">
                <h3 className="font-semibold text-lg text-on-surface-variant">Regional Visualization</h3>
                 <div className="relative">
                    <select
                        value={activeRegion}
                        onChange={(e) => onRegionChange(e.target.value)}
                        className="w-full appearance-none p-3 bg-surface-container-high border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-on-surface"
                    >
                        {regions.map(r => <option key={r} value={r}>{r === 'all' ? 'All Regions' : r}</option>)}
                    </select>
                    <span className="material-symbols-outlined absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">arrow_drop_down</span>
                 </div>
            </div>

            <div className="border-t border-outline-variant pt-6 space-y-4">
                <h3 className="font-semibold text-lg text-on-surface-variant">Data Layers</h3>
                
                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <span className="material-symbols-outlined text-secondary">person_pin_circle</span>
                        <label className="font-medium">My Location</label>
                    </div>
                    <ToggleSwitch 
                        checked={showUserLocation}
                        onChange={onToggleUserLocation}
                        disabled={!userLocation}
                    />
                </div>

                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <span className="material-symbols-outlined text-secondary">cloud</span>
                        <label className="font-medium">Cloud Cover</label>
                    </div>
                    <ToggleSwitch
                        checked={showClouds}
                        onChange={onToggleClouds}
                    />
                </div>

                <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <span className="material-symbols-outlined text-secondary">heatmap</span>
                        <label className="font-medium">Member Density</label>
                    </div>
                    <ToggleSwitch
                        checked={showMemberDensity}
                        onChange={onToggleMemberDensity}
                    />
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default MapControlPanel;