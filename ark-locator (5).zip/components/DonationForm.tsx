import React, { useState } from 'react';

interface DonationFormProps {
    zoneName: string;
}

const DonationForm: React.FC<DonationFormProps> = ({ zoneName }) => {
  const [amount, setAmount] = useState('50');
  const [customAmount, setCustomAmount] = useState('');
  
  const presetAmounts = ['25', '50', '100', '250'];

  const handleAmountClick = (value: string) => {
    setAmount(value);
    setCustomAmount('');
  }
  
  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    setCustomAmount(value);
    setAmount('');
  }

  const selectedAmount = customAmount || amount;

  return (
    <div className="max-w-md mx-auto">
        <div className="text-center mb-6">
            <h3 className="text-xl font-bold text-on-surface">Support Mission: {zoneName}</h3>
            <p className="text-on-surface-variant">Your contribution fuels our global and local operations.</p>
        </div>
      
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
            {presetAmounts.map(preset => (
                <button
                    key={preset}
                    onClick={() => handleAmountClick(preset)}
                    className={`p-3 rounded-lg font-semibold transition-colors ${amount === preset ? 'bg-primary-container text-on-primary-container' : 'bg-surface-container-high hover:bg-surface-container-highest text-on-surface'}`}
                >
                    ${preset}
                </button>
            ))}
        </div>

        <div className="mb-6">
            <label htmlFor="custom-amount" className="sr-only">Custom Amount</label>
            <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-on-surface-variant">$</div>
                <input
                    type="text"
                    id="custom-amount"
                    value={customAmount}
                    onChange={handleCustomAmountChange}
                    placeholder="Custom amount"
                    className="w-full pl-8 p-4 bg-surface-container border border-outline rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-on-surface placeholder-on-surface-variant"
                />
            </div>
        </div>

        <button 
            disabled={!selectedAmount || parseInt(selectedAmount) <= 0}
            className="w-full flex items-center justify-center space-x-2 bg-primary text-on-primary font-bold py-3 px-4 rounded-full transition-colors duration-200 hover:bg-primary/90 disabled:bg-on-surface/20 disabled:text-on-surface/50 disabled:cursor-not-allowed"
        >
            <span className="material-symbols-outlined">card_giftcard</span>
            <span>Give ${selectedAmount}</span>
        </button>
        <p className="text-center text-xs text-on-surface-variant mt-3 flex items-center justify-center space-x-1">
            <span className="material-symbols-outlined text-sm">lock</span>
            <span>Secure SSL/TLS Encrypted Transaction</span>
        </p>
    </div>
  );
};

export default DonationForm;