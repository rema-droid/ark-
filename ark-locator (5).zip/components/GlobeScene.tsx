import React, { useRef, useEffect } from 'react';
import { ZoneData } from '../types';
import { ZONES_DATA, GLOBE_RADIUS } from '../constants';

// Since we can't import, we declare the THREE global.
declare const THREE: any;

interface GlobeSceneProps {
  onHoverZone: (zone: ZoneData | null) => void;
  onZoneClick: (zone: ZoneData) => void;
  setTooltip: (tooltip: { x: number; y: number; content: string } | null) => void;
  hoveredZone: ZoneData | null;
  zoomedZone: ZoneData | null;
  userLocation: { lat: number; lon: number } | null;
  showUserLocation: boolean;
  showClouds: boolean;
  showMemberDensity: boolean;
  activeRegion: string;
  onAnimationComplete: () => void;
}

const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Radius of the earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // Distance in km
};

const latLonToVector3 = (lat: number, lon: number, radius: number): [number, number, number] => {
  const phi = (90 - lat) * (Math.PI / 180);
  const theta = (lon + 180) * (Math.PI / 180);
  const x = -(radius * Math.sin(phi) * Math.cos(theta));
  const y = radius * Math.cos(phi);
  const z = radius * Math.sin(phi) * Math.sin(theta);
  return [x, y, z];
};

const GlobeScene: React.FC<GlobeSceneProps> = ({ 
    onHoverZone, onZoneClick, setTooltip, hoveredZone, zoomedZone,
    userLocation, showUserLocation, showClouds, onAnimationComplete,
    showMemberDensity, activeRegion
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef({ onHoverZone, onZoneClick, setTooltip, hoveredZone, zoomedZone, userLocation, showUserLocation, showClouds, onAnimationComplete, showMemberDensity, activeRegion });
  
  useEffect(() => {
    stateRef.current = { onHoverZone, onZoneClick, setTooltip, hoveredZone, zoomedZone, userLocation, showUserLocation, showClouds, onAnimationComplete, showMemberDensity, activeRegion };
  }, [onHoverZone, onZoneClick, setTooltip, hoveredZone, zoomedZone, userLocation, showUserLocation, showClouds, onAnimationComplete, showMemberDensity, activeRegion]);

  useEffect(() => {
    if (!mountRef.current || typeof THREE === 'undefined') return;

    const mount = mountRef.current;
    let animationFrameId: number;
    let isMouseDown = false;
    let lastMouseX = 0;
    let lastMouseY = 0;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    mount.appendChild(renderer.domElement);

    // Lighting
    scene.add(new THREE.AmbientLight(0xcccccc, 1.2));
    const light = new THREE.DirectionalLight(0xffffff, 1.0);
    light.position.set(5, 5, 5);
    scene.add(light);
    
    // Globe Group
    const globeGroup = new THREE.Group();
    scene.add(globeGroup);

    // Earth Mesh
    const textureLoader = new THREE.TextureLoader();
    const earthTexture = textureLoader.load('https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x5400x2700.jpg');
    const specularMap = textureLoader.load('https://raw.githubusercontent.com/turban/webgl-earth/master/images/water_4k.png');
    const bumpMap = textureLoader.load('https://eoimages.gsfc.nasa.gov/images/imagerecords/73000/73909/world.topo.bathy.200412.3x5400x2700.jpg'); // Using same for bump
    const earthMaterial = new THREE.MeshPhongMaterial({ 
        map: earthTexture,
        specularMap: specularMap,
        specular: new THREE.Color('grey'),
        bumpMap: bumpMap,
        bumpScale: 0.5,
    });
    const earthMesh = new THREE.Mesh(new THREE.SphereGeometry(GLOBE_RADIUS, 64, 64), earthMaterial);
    globeGroup.add(earthMesh);

    // Cloud Layer
    const cloudTexture = textureLoader.load('https://raw.githubusercontent.com/turban/webgl-earth/master/images/fair_clouds_4k.png');
    const cloudMaterial = new THREE.MeshPhongMaterial({ map: cloudTexture, transparent: true, opacity: 0.3 });
    const cloudMesh = new THREE.Mesh(new THREE.SphereGeometry(GLOBE_RADIUS + 0.5, 64, 64), cloudMaterial);
    globeGroup.add(cloudMesh);

    // Atmosphere
    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: `varying vec3 vNormal; void main() { vNormal = normalize( normalMatrix * normal ); gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 ); }`,
      fragmentShader: `uniform float c; uniform float p; varying vec3 vNormal; void main() { float intensity = pow( c - dot( vNormal, vec3( 0.0, 0.0, 1.0 ) ), p ); gl_FragColor = vec4( 0.64, 0.78, 1.0, 0.5 ) * intensity; }`,
      uniforms: { c: { value: 0.2 }, p: { value: 4.0 } },
      blending: THREE.AdditiveBlending, side: THREE.BackSide, transparent: true,
    });
    const atmosphereMesh = new THREE.Mesh(new THREE.SphereGeometry(GLOBE_RADIUS * 1.1, 64, 64), atmosphereMaterial);
    globeGroup.add(atmosphereMesh);

    // Particles
    const particleCount = 2000;
    const particles = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i++) {
        const theta = Math.random() * 2 * Math.PI;
        const phi = Math.acos(2 * Math.random() - 1);
        const radius = GLOBE_RADIUS + 50 + Math.random() * 50;
        positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
        positions[i * 3 + 1] = radius * Math.cos(phi);
        positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
    }
    particles.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const particleMaterial = new THREE.PointsMaterial({ color: 0x8d9199, size: 0.5, transparent: true, opacity: 0.5 }); // outline
    const particleSystem = new THREE.Points(particles, particleMaterial);
    scene.add(particleSystem);
    
    // User Location Marker
    const userMarkerGeom = new THREE.SphereGeometry(1.2, 16, 16);
    const userMarkerMat = new THREE.MeshBasicMaterial({ color: 0xa4c8ff }); // primary
    const userMarker = new THREE.Mesh(userMarkerGeom, userMarkerMat);
    const userPulseGeom = new THREE.SphereGeometry(1.5, 16, 16);
    const userPulseMat = new THREE.MeshBasicMaterial({ color: 0xa4c8ff, transparent: true }); // primary
    const userPulseMarker = new THREE.Mesh(userPulseGeom, userPulseMat);
    const userMarkerGroup = new THREE.Group();
    userMarkerGroup.add(userMarker);
    userMarkerGroup.add(userPulseMarker);
    userMarkerGroup.visible = false;
    globeGroup.add(userMarkerGroup);

    // Zone Markers & Heatmap
    const markers: any[] = [];
    const heatmapMeshes: any[] = [];
    const maxUsers = Math.max(...ZONES_DATA.map(z => z.userCount));
    const primaryColor = new THREE.Color(0xa4c8ff);
    const secondaryColor = new THREE.Color(0xbdc7d8);
    
    const heatmapMaterial = new THREE.MeshBasicMaterial({ color: 0xff8000, transparent: true, blending: THREE.AdditiveBlending });

    ZONES_DATA.forEach(zone => {
      const position = latLonToVector3(zone.lat, zone.lon, GLOBE_RADIUS);
      const markerGeom = new THREE.SphereGeometry(1.2, 16, 16);
      const markerMat = new THREE.MeshPhongMaterial({ color: primaryColor });
      const marker = new THREE.Mesh(markerGeom, markerMat);
      marker.position.set(...position);
      marker.userData = zone;
      globeGroup.add(marker);
      markers.push(marker);
      
      const heatmapSize = 4 + (zone.userCount / maxUsers) * 15;
      const heatmapGeom = new THREE.CircleGeometry(heatmapSize, 32);
      const heatmapMesh = new THREE.Mesh(heatmapGeom, heatmapMaterial.clone());
      heatmapMesh.position.copy(marker.position);
      heatmapMesh.lookAt(new THREE.Vector3(0,0,0).multiplyScalar(2));
      heatmapMesh.material.opacity = 0.1 + (zone.userCount / maxUsers) * 0.4;
      heatmapMesh.visible = false;
      globeGroup.add(heatmapMesh);
      heatmapMeshes.push({mesh: heatmapMesh, zoneId: zone.id});
    });

    // Flight path
    const flightPathGroup = new THREE.Group();
    let flightPathMesh: any = null;
    globeGroup.add(flightPathGroup);

    // Raycasting
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let intersected: any | null = null;
    
    // Animation state
    const animationControls = {
        isAnimating: false,
        cameraTargetPos: new THREE.Vector3(0, 0, 300),
        globeTargetQuat: new THREE.Quaternion(),
    };
    let lastProcessedZoomedZoneId: string | null | undefined = 'initial';

    const onRotate = (deltaX: number) => {
        globeGroup.rotation.y += deltaX * 0.005;
    };
    
    const onDrag = (event: MouseEvent) => {
      if (isMouseDown && !animationControls.isAnimating) {
        const deltaX = event.clientX - lastMouseX;
        onRotate(deltaX);
        lastMouseX = event.clientX;
      }
    }

    function onMouseMove(event: MouseEvent) {
      if(isMouseDown) return onDrag(event);

      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(markers.filter(m => m.visible && m.material.opacity > 0.5));

      if (intersects.length > 0) {
        if (intersected !== intersects[0].object) {
          intersected = intersects[0].object;
          const zoneData = intersected.userData as ZoneData;
          stateRef.current.onHoverZone(zoneData);
          stateRef.current.setTooltip({ x: event.clientX, y: event.clientY, content: zoneData.name });
        }
      } else {
        if (intersected) {
          stateRef.current.onHoverZone(null);
          stateRef.current.setTooltip(null);
        }
        intersected = null;
      }
    }
    
    function onClick(event: MouseEvent) {
        if(Math.abs(event.clientX - lastMouseX) > 5 || Math.abs(event.clientY - lastMouseY) > 5) return;
        if(intersected) {
            stateRef.current.onZoneClick(intersected.userData as ZoneData);
        }
    }

    function onMouseDown(event: MouseEvent) {
        isMouseDown = true;
        lastMouseX = event.clientX;
        lastMouseY = event.clientY;
    }

    function onMouseUp() { isMouseDown = false; }

    mount.addEventListener('mousemove', onMouseMove);
    mount.addEventListener('click', onClick);
    mount.addEventListener('mousedown', onMouseDown);
    mount.addEventListener('mouseup', onMouseUp);
    mount.addEventListener('mouseleave', onMouseUp);

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const { zoomedZone, hoveredZone, userLocation, showUserLocation, showClouds, showMemberDensity, activeRegion } = stateRef.current;
      
      if(lastProcessedZoomedZoneId !== zoomedZone?.id) {
          lastProcessedZoomedZoneId = zoomedZone?.id;
          animationControls.isAnimating = true;
          const tempLookAt = new THREE.Object3D();
          if(zoomedZone) {
              animationControls.cameraTargetPos.set(0, 0, GLOBE_RADIUS * 1.8);
              const targetVec = new THREE.Vector3(...latLonToVector3(zoomedZone.lat, zoomedZone.lon, GLOBE_RADIUS));
              tempLookAt.lookAt(targetVec);
              animationControls.globeTargetQuat.copy(tempLookAt.quaternion);

              if (userLocation && showUserLocation) {
                 if (flightPathMesh) flightPathGroup.remove(flightPathMesh);
                 const startVec = new THREE.Vector3(...latLonToVector3(userLocation.lat, userLocation.lon, GLOBE_RADIUS));
                 const endVec = new THREE.Vector3(...latLonToVector3(zoomedZone.lat, zoomedZone.lon, GLOBE_RADIUS));
                 const midVec = startVec.clone().lerp(endVec, 0.5).normalize().multiplyScalar(GLOBE_RADIUS + 25);
                 const curve = new THREE.CatmullRomCurve3([startVec, midVec, endVec]);
                 const tubeGeom = new THREE.TubeGeometry(curve, 32, 0.2, 8, false);
                 const tubeMat = new THREE.MeshBasicMaterial({ color: 0xa4c8ff, transparent: true, opacity: 0.8 });
                 flightPathMesh = new THREE.Mesh(tubeGeom, tubeMat);
                 flightPathGroup.add(flightPathMesh);
              }
          } else {
              animationControls.cameraTargetPos.set(0, 0, 300);
              animationControls.globeTargetQuat.identity();
          }
      }

      if(animationControls.isAnimating) {
          camera.position.lerp(animationControls.cameraTargetPos, 0.05);
          globeGroup.quaternion.slerp(animationControls.globeTargetQuat, 0.05);
          if (flightPathMesh) flightPathMesh.material.opacity = Math.max(0, flightPathMesh.material.opacity - 0.02);

          if(camera.position.distanceTo(animationControls.cameraTargetPos) < 0.1 && globeGroup.quaternion.angleTo(animationControls.globeTargetQuat) < 0.01) {
              animationControls.isAnimating = false;
              stateRef.current.onAnimationComplete();
              if (flightPathMesh) flightPathGroup.remove(flightPathMesh);
              flightPathMesh = null;
          }
      } else if (!isMouseDown) {
          globeGroup.rotation.y += zoomedZone ? 0.0002 : 0.0005;
      }
      particleSystem.rotation.y += 0.0001;
      cloudMesh.rotation.y += 0.00015;
      
      // Update layers
      cloudMesh.visible = showClouds;
      if (userLocation && showUserLocation) {
        userMarkerGroup.visible = true;
        const userPos = new THREE.Vector3(...latLonToVector3(userLocation.lat, userLocation.lon, GLOBE_RADIUS));
        userMarkerGroup.position.copy(userPos);

        const pulseFactor = (Math.sin(Date.now() * 0.002) + 1) / 2; // Oscillates 0 to 1
        const scale = 1 + pulseFactor * 2;
        userPulseMarker.scale.set(scale, scale, scale);
        userPulseMarker.material.opacity = 1 - pulseFactor;

      } else {
        userMarkerGroup.visible = false;
      }

      const hoveredZoneId = hoveredZone?.id;
      markers.forEach((marker, index) => {
          const zoneData = marker.userData;
          const isHovered = zoneData.id === hoveredZoneId;
          const inRegion = activeRegion === 'all' || zoneData.region === activeRegion;
          
          marker.visible = inRegion;
          
          const targetScale = isHovered ? 1.8 : 1;
          marker.scale.lerp(new THREE.Vector3(targetScale,targetScale,targetScale), 0.1);

          if(zoomedZone && zoomedZone.id === zoneData.id) {
            marker.scale.set(2, 2, 2);
          }
          
          const targetColor = (isHovered || (zoomedZone && zoomedZone.id === zoneData.id)) ? secondaryColor : primaryColor;
          marker.material.color.lerp(targetColor, 0.1);
          
          heatmapMeshes[index].mesh.visible = showMemberDensity && inRegion;
      });

      renderer.render(scene, camera);
    };
    animate();

    const onResize = () => {
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      window.removeEventListener('resize', onResize);
      mount.removeEventListener('mousemove', onMouseMove);
      mount.removeEventListener('click', onClick);
      mount.removeEventListener('mousedown', onMouseDown);
      mount.removeEventListener('mouseup', onMouseUp);
      mount.removeEventListener('mouseleave', onMouseUp);
      cancelAnimationFrame(animationFrameId);
      if(renderer.domElement) mount.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />;
};

export default GlobeScene;