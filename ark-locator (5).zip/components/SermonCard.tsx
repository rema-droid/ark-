import React from 'react';
import { Sermon } from '../types';

interface SermonCardProps {
  sermon: Sermon;
}

const SermonCard: React.FC<SermonCardProps> = ({ sermon }) => {
  return (
    <a 
      href={sermon.videoUrl} 
      target="_blank" 
      rel="noopener noreferrer"
      className="bg-surface-container rounded-xl flex flex-col border border-outline hover:border-primary/50 transition-all duration-300 group overflow-hidden shadow-md hover:shadow-xl hover:-translate-y-1"
    >
      <div className="relative">
        <img src={sermon.thumbnailUrl} alt={sermon.title} className="w-full h-40 object-cover transition-transform duration-300 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 scale-75 group-hover:scale-100">
                <span className="material-symbols-outlined text-on-primary text-5xl">play_arrow</span>
            </div>
        </div>
        <div className="absolute bottom-0 left-0 p-4">
            <h3 className="text-lg font-bold text-white transition-colors">{sermon.title}</h3>
        </div>
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <div>
            <p className="text-sm font-semibold text-on-surface-variant">{sermon.speaker}</p>
            <p className="text-xs text-on-surface-variant/80 mt-1">{sermon.date}</p>
        </div>
        <div className="mt-4 pt-4 border-t border-outline-variant text-right">
            <span className="text-primary font-semibold text-sm group-hover:underline">
                Watch Now
            </span>
        </div>
      </div>
    </a>
  );
};

export default SermonCard;