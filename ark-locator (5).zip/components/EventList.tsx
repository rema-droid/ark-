import React from 'react';
import { Event } from '../types';

interface EventListProps {
  events: Event[];
}

const EventList: React.FC<EventListProps> = ({ events }) => {
  if (events.length === 0) {
    return <p className="text-on-surface-variant">No upcoming events scheduled.</p>;
  }

  return (
    <div className="space-y-4">
      {events.map(event => (
        <div key={event.id} className="bg-surface-container-high p-4 rounded-xl flex items-start space-x-4">
          <div className="bg-secondary-container p-3 rounded-full mt-1">
            <span className="material-symbols-outlined text-on-secondary-container">calendar_month</span>
          </div>
          <div>
            <h4 className="font-bold text-on-surface">{event.title}</h4>
            <p className="text-on-surface-variant">{event.date} at {event.time}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default EventList;