export interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  description?: string;
}

export interface GlobalEvent {
  id: string;
  title: string;
  date: string;
  type: 'Conference' | 'Livestream' | 'Special Service';
  description: string;
  link?: string;
}

export interface ZoneData {
  id:string;
  name: string;
  leader: string;
  phone: string;
  location: string;
  userCount: number;
  events: Event[];
  lat: number;
  lon: number;
  region: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
  sources?: { uri: string; title: string }[];
}

export interface Sermon {
    id: string;
    title: string;
    speaker: string;
    date: string;
    thumbnailUrl: string;
    videoUrl: string;
}

export interface UserProfile {
    id: string;
    name: string;
    email: string;
    zoneAffiliation: string;
    imageUrl: string;
    titheHistory: {
        id: string;
        date: string;
        amount: number;
        zone: string;
    }[];
}