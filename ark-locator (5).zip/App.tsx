import React, { useState, useCallback, useEffect, useRef } from 'react';
import { ZoneData } from './types';
import Header from './components/Header';
import DirectoryPage from './pages/DirectoryPage';
import ProfilePage from './pages/ProfilePage';
import EventsPage from './pages/EventsPage';
import GlobeScene from './components/GlobeScene';
import InfoPanel from './components/InfoPanel';
import BottomNavBar from './components/BottomNavBar';
import MapControlPanel from './components/MapControlPanel';
import AgentProfilePage from './pages/AgentProfilePage';
import TransmissionsPage from './pages/TransmissionsPage';
import { ZONES_DATA } from './constants';
import { ChatPanel } from './components/ChatPanel';

declare global {
  namespace JSX {
    interface IntrinsicElements {
      'chat-panel': React.DetailedHTMLProps<React.HTMLAttributes<ChatPanel> & { isopen?: string }, ChatPanel>;
    }
  }
}

type ViewMode = 'globe' | 'directory' | 'events' | 'transmissions' | 'agentProfile';

const getDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in km
};

function App(): React.ReactNode {
  const [viewMode, setViewMode] = useState<ViewMode>('globe');
  const [selectedZone, setSelectedZone] = useState<ZoneData | null>(null);
  
  // States for Globe view
  const [hoveredZone, setHoveredZone] = useState<ZoneData | null>(null);
  const [tooltip, setTooltip] = useState<{ x: number, y: number, content: string } | null>(null);
  const [zoomedZone, setZoomedZone] = useState<ZoneData | null>(null);
  const [isFlying, setIsFlying] = useState(false);

  // Panel states and map controls
  const [userLocation, setUserLocation] = useState<{ lat: number, lon: number } | null>(null);
  const [isMcPanelOpen, setIsMcPanelOpen] = useState(false);
  const [isChatPanelOpen, setIsChatPanelOpen] = useState(false);
  const [showUserLocation, setShowUserLocation] = useState(true);
  const [showClouds, setShowClouds] = useState(true);
  const [showMemberDensity, setShowMemberDensity] = useState(false);
  const [activeRegion, setActiveRegion] = useState<string>('all');


  const chatPanelRef = useRef<ChatPanel>(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      console.error("Geolocation is not supported by this browser.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lon: position.coords.longitude,
        });
      },
      (error) => {
        console.error("Geolocation error:", error.message);
      }
    );
  }, []);

  useEffect(() => {
    const node = chatPanelRef.current;
    if (!node) return;

    const handleZoom = (event: Event) => {
        const customEvent = event as CustomEvent<ZoneData>;
        if (customEvent.detail) {
            handleSwitchView('globe');
            setZoomedZone(customEvent.detail);
            setIsFlying(true);
            setIsChatPanelOpen(false);
        }
    };
    
    const handleClose = () => setIsChatPanelOpen(false);

    node.addEventListener('zoom-to-zone', handleZoom);
    node.addEventListener('close-requested', handleClose);
    return () => {
        node.removeEventListener('zoom-to-zone', handleZoom);
        node.removeEventListener('close-requested', handleClose);
    };
  }, [chatPanelRef]);

  const handleSelectZoneForProfile = useCallback((zone: ZoneData) => {
    setSelectedZone(zone);
    setHoveredZone(null); 
    setTooltip(null);
    setZoomedZone(null);
    setIsMcPanelOpen(false);
    setIsChatPanelOpen(false);
    window.scrollTo(0, 0);
  }, []);

  const handleBackTo = useCallback((view: ViewMode) => {
    setSelectedZone(null);
    setViewMode(view);
    window.scrollTo(0,0);
  }, []);

  const handleHoverZone = useCallback((zone: ZoneData | null) => {
      if(!selectedZone && !zoomedZone && !isFlying){
        setHoveredZone(zone);
      }
  }, [selectedZone, zoomedZone, isFlying]);
  
  const handleSwitchView = useCallback((view: ViewMode) => {
      setViewMode(view);
      setSelectedZone(null);
      setHoveredZone(null);
      setTooltip(null);
      setZoomedZone(null);
  }, []);

  const handleZoneClickOnGlobe = useCallback((zone: ZoneData) => {
    if (zoomedZone && zoomedZone.id === zone.id) {
        handleSelectZoneForProfile(zone);
    } else {
        setZoomedZone(zone);
        setIsFlying(true);
        setHoveredZone(null);
        setTooltip(null);
    }
  }, [zoomedZone, handleSelectZoneForProfile]);

  const handleZoomOut = useCallback(() => {
    setZoomedZone(null);
    setIsFlying(true);
  }, []);

  const handleFindNearestZone = useCallback(() => {
    if (!userLocation) return;
    let nearestZone: ZoneData | null = null;
    let minDistance = Infinity;

    ZONES_DATA.forEach(zone => {
      const distance = getDistance(userLocation.lat, userLocation.lon, zone.lat, zone.lon);
      if (distance < minDistance) {
        minDistance = distance;
        nearestZone = zone;
      }
    });

    if (nearestZone) {
      handleSwitchView('globe');
      setZoomedZone(nearestZone);
      setIsFlying(true);
      setIsMcPanelOpen(false);
    }
  }, [userLocation]);

  const renderMainContent = () => {
    if (viewMode === 'agentProfile') {
        return <AgentProfilePage onBack={() => handleBackTo('globe')} />;
    }
    if (selectedZone) {
        return <ProfilePage zone={selectedZone} onBack={() => handleBackTo('directory')} />;
    }
    
    return (
        <>
            <div className="absolute inset-0 top-0 z-0">
                <div className={`view-container ${viewMode !== 'globe' ? 'hidden' : ''}`}>
                    <GlobeScene
                        onHoverZone={handleHoverZone}
                        onZoneClick={handleZoneClickOnGlobe}
                        setTooltip={setTooltip}
                        hoveredZone={hoveredZone} 
                        zoomedZone={zoomedZone}
                        userLocation={userLocation}
                        showUserLocation={showUserLocation}
                        showClouds={showClouds}
                        showMemberDensity={showMemberDensity}
                        activeRegion={activeRegion}
                        onAnimationComplete={() => setIsFlying(false)}
                    />
                </div>
                <div className={`view-container h-full overflow-y-auto ${viewMode !== 'directory' ? 'hidden' : ''}`}>
                    <DirectoryPage onSelectZone={handleSelectZoneForProfile} />
                </div>
                <div className={`view-container h-full overflow-y-auto ${viewMode !== 'events' ? 'hidden' : ''}`}>
                    <EventsPage />
                </div>
                 <div className={`view-container h-full overflow-y-auto ${viewMode !== 'transmissions' ? 'hidden' : ''}`}>
                    <TransmissionsPage />
                </div>
            </div>
        </>
    );
  };


  return (
    <div className="relative min-h-screen bg-surface text-on-surface font-sans overflow-hidden">
      <Header onShowAgentProfile={() => setViewMode('agentProfile')} />
      <main className="w-full h-[calc(100vh-72px)]">
        <div className="h-full">
            {renderMainContent()}
        </div>
      </main>
      
       {viewMode !== 'agentProfile' && !selectedZone && (
         <BottomNavBar currentView={viewMode} onSwitchView={handleSwitchView} />
       )}
      
      {/* Globe-specific UI overlays */}
      {viewMode === 'globe' && !selectedZone && (
        <>
          {zoomedZone && (
             <button
                onClick={handleZoomOut}
                className="absolute top-24 md:top-28 left-4 z-20 flex items-center space-x-2 bg-surface-container/80 backdrop-blur-sm text-on-surface font-semibold py-2 px-4 rounded-full hover:bg-surface-container-high transition-colors"
             >
                <span className="material-symbols-outlined">arrow_back</span>
                <span>Global View</span>
            </button>
          )}

           <div className="absolute bottom-24 right-4 md:bottom-6 md:right-6 z-20 flex flex-col space-y-4">
              <button
                onClick={() => setIsChatPanelOpen(p => !p)}
                className="flex items-center justify-center w-14 h-14 bg-tertiary-container rounded-2xl text-on-tertiary-container shadow-lg hover:bg-tertiary-container/80 transition-all transform hover:scale-105"
                aria-label="Toggle AI Chat"
              >
                  <span className="material-symbols-outlined">chat</span>
              </button>
              <button
                onClick={() => setIsMcPanelOpen(p => !p)}
                className="flex items-center justify-center w-14 h-14 bg-secondary-container rounded-2xl text-on-secondary-container shadow-lg hover:bg-secondary-container/80 transition-all transform hover:scale-105"
                aria-label="Toggle Map Controls"
              >
                <span className="material-symbols-outlined">layers</span>
              </button>
           </div>
          
           <chat-panel ref={chatPanelRef} isopen={isChatPanelOpen.toString()}></chat-panel>

          <MapControlPanel 
            isOpen={isMcPanelOpen}
            onClose={() => setIsMcPanelOpen(false)}
            userLocation={userLocation}
            onFindNearest={handleFindNearestZone}
            showUserLocation={showUserLocation}
            onToggleUserLocation={() => setShowUserLocation(p => !p)}
            showClouds={showClouds}
            onToggleClouds={() => setShowClouds(p => !p)}
            showMemberDensity={showMemberDensity}
            onToggleMemberDensity={() => setShowMemberDensity(p => !p)}
            activeRegion={activeRegion}
            onRegionChange={setActiveRegion}
          />

          <InfoPanel 
            zone={hoveredZone} 
            onClose={() => setHoveredZone(null)}
            onSelect={handleSelectZoneForProfile}
          />

          {tooltip && (
            <div
              className="fixed p-2 text-sm bg-black/60 text-white rounded-md pointer-events-none z-50 transform -translate-y-full -translate-x-1/2"
              style={{ left: `${tooltip.x}px`, top: `${tooltip.y - 15}px` }}
            >
              {tooltip.content}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;