import React, { useState } from 'react';
import { ZoneData } from '../types';
import EventList from '../components/EventList';
import DonationForm from '../components/DonationForm';

interface ProfilePageProps {
  zone: ZoneData;
  onBack: () => void;
}

type Tab = 'intel' | 'briefings' | 'give';

const ProfilePage: React.FC<ProfilePageProps> = ({ zone, onBack }) => {
  const [activeTab, setActiveTab] = useState<Tab>('intel');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'briefings':
        return <EventList events={zone.events} />;
      case 'give':
        return <DonationForm zoneName={zone.name} />;
      case 'intel':
      default:
        return (
          <div className="space-y-4 text-on-surface-variant">
            <div className="flex items-center space-x-4">
              <span className="material-symbols-outlined w-6 h-6 text-secondary flex-shrink-0">account_circle</span>
              <div>
                <p className="font-semibold text-on-surface">Zone Coordinator</p>
                <p>{zone.leader}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="material-symbols-outlined w-6 h-6 text-secondary flex-shrink-0">call</span>
              <div>
                <p className="font-semibold text-on-surface">Contact</p>
                <p>{zone.phone}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="material-symbols-outlined w-6 h-6 text-secondary flex-shrink-0">group</span>
              <div>
                <p className="font-semibold text-on-surface">Active Members</p>
                <p>{zone.userCount.toLocaleString()}</p>
              </div>
            </div>
             <div className="flex items-center space-x-4">
              <span className="material-symbols-outlined w-6 h-6 text-secondary flex-shrink-0">public</span>
              <div>
                <p className="font-semibold text-on-surface">Region</p>
                <p>{zone.region}</p>
              </div>
            </div>
          </div>
        );
    }
  };
  
  const TabButton: React.FC<{tab: Tab, label: string, icon: string}> = ({tab, label, icon}) => (
    <button
        onClick={() => setActiveTab(tab)}
        className={`relative flex-1 flex flex-col items-center justify-center space-y-1 py-3 px-2 text-sm font-semibold transition-colors duration-300 ${activeTab === tab ? 'text-primary' : 'text-on-surface-variant hover:text-on-surface'}`}
    >
        <span className="material-symbols-outlined">{icon}</span>
        <span>{label}</span>
        {activeTab === tab && (
          <div className="absolute bottom-0 h-1 w-full max-w-16 bg-primary rounded-t-full"></div>
        )}
    </button>
  );

  return (
    <div className="container mx-auto p-4 md:p-8 h-full">
      <div className="flex mb-6">
        <button onClick={onBack} className="flex items-center space-x-2 text-primary hover:bg-primary/10 font-semibold px-4 py-2 rounded-full transition-colors">
          <span className="material-symbols-outlined">arrow_back</span>
          <span>Back</span>
        </button>
      </div>

      <div className="bg-surface-container rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6">
            <h1 className="text-3xl font-bold text-on-surface">{zone.name}</h1>
            <div className="flex items-center space-x-2 mt-2 text-on-surface-variant">
                <span className="material-symbols-outlined w-5 h-5">location_on</span>
                <span>{zone.location}</span>
            </div>
        </div>

        <div className="border-b border-outline-variant">
            <div className="flex">
                <TabButton tab="intel" label="Intel" icon="person_search" />
                <TabButton tab="briefings" label="Briefings" icon="event" />
                <TabButton tab="give" label="Support" icon="volunteer_activism" />
            </div>
        </div>

        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;