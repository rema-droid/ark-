import React from 'react';
import { MOCK_USER_PROFILE } from '../constants';

interface AgentProfilePageProps {
  onBack: () => void;
}

const AgentProfilePage: React.FC<AgentProfilePageProps> = ({ onBack }) => {
  const user = MOCK_USER_PROFILE;

  return (
    <div className="container mx-auto p-4 md:p-8 h-full">
      <div className="flex mb-6">
        <button onClick={onBack} className="flex items-center space-x-2 text-primary hover:bg-primary/10 font-semibold px-4 py-2 rounded-full transition-colors">
          <span className="material-symbols-outlined">arrow_back</span>
          <span>Back</span>
        </button>
      </div>
      <div className="bg-surface-container rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 md:flex md:items-center md:space-x-6">
          <img src={user.imageUrl} alt={user.name} className="w-32 h-32 rounded-full mx-auto md:mx-0 ring-4 ring-primary" />
          <div className="text-center md:text-left mt-4 md:mt-0">
            <h1 className="text-3xl font-bold text-on-surface">{user.name}</h1>
            <p className="text-secondary">{user.email}</p>
            <p className="text-on-surface-variant mt-1">Zone Affiliation: <span className="font-semibold text-on-surface">{user.zoneAffiliation}</span></p>
          </div>
          <div className="mt-6 md:mt-0 md:ml-auto flex flex-col items-center sm:flex-row sm:space-x-2 space-y-2 sm:space-y-0">
             <button className="bg-primary hover:bg-primary/90 text-on-primary font-bold py-2 px-6 rounded-full transition-colors w-full sm:w-auto">Edit Profile</button>
             <button className="border border-outline text-on-surface-variant hover:bg-on-surface/10 font-bold py-2 px-6 rounded-full transition-colors w-full sm:w-auto">Logout</button>
          </div>
        </div>

        <div className="border-t border-outline-variant p-6">
          <h2 className="text-2xl font-bold text-on-surface mb-4">Mission Support History</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="text-xs text-on-surface-variant uppercase bg-surface-container-high">
                <tr>
                  <th scope="col" className="px-6 py-3 rounded-l-lg">Date</th>
                  <th scope="col" className="px-6 py-3">Zone</th>
                  <th scope="col" className="px-6 py-3 text-right rounded-r-lg">Amount</th>
                </tr>
              </thead>
              <tbody>
                {user.titheHistory.map(record => (
                  <tr key={record.id} className="border-b border-surface-container-high last:border-b-0">
                    <td className="px-6 py-4 font-medium text-on-surface">{record.date}</td>
                    <td className="px-6 py-4 text-on-surface-variant">{record.zone}</td>
                    <td className="px-6 py-4 text-right font-semibold text-on-surface">${record.amount.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentProfilePage;