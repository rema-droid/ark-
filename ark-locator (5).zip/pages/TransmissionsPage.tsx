import React from 'react';
import { SERMONS_DATA } from '../constants';
import SermonCard from '../components/SermonCard';

const TransmissionsPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-on-surface mb-2">Transmissions</h1>
        <p className="text-on-surface-variant max-w-2xl mx-auto">Access powerful teachings and messages from our leadership. Tune in to stay spiritually nourished and connected.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {SERMONS_DATA.map(sermon => (
          <SermonCard key={sermon.id} sermon={sermon} />
        ))}
      </div>
    </div>
  );
};

export default TransmissionsPage;