import React from 'react';
import { GLOBAL_EVENTS_DATA } from '../constants';
import { GlobalEvent } from '../types';

const EventCard: React.FC<{ event: GlobalEvent }> = ({ event }) => {
    const getEventTypeColor = (type: GlobalEvent['type']) => {
        switch (type) {
            case 'Conference': return 'bg-primary-container text-on-primary-container';
            case 'Livestream': return 'bg-secondary-container text-on-secondary-container';
            case 'Special Service': return 'bg-tertiary-container text-on-tertiary-container';
            default: return 'bg-surface-container-highest text-on-surface';
        }
    }

    return (
        <div className="bg-surface-container rounded-xl p-6 flex flex-col border border-outline hover:bg-on-surface/[.08] transition-colors">
            <div className="flex-grow">
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <p className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${getEventTypeColor(event.type)}`}>{event.type}</p>
                        <h3 className="text-xl font-bold text-on-surface mt-2">{event.title}</h3>
                    </div>
                    <div className="bg-surface-container-high p-3 rounded-full">
                        <span className="material-symbols-outlined text-secondary w-8 h-8 flex items-center justify-center">event</span>
                    </div>
                </div>
                <p className="text-on-surface-variant mb-2">{event.date}</p>
                <p className="text-on-surface-variant">{event.description}</p>
            </div>
            {event.link && (
                 <a href={event.link} target="_blank" rel="noopener noreferrer" className="mt-6 inline-block text-center bg-primary hover:bg-primary/90 text-on-primary font-bold py-2 px-4 rounded-full transition-colors duration-200">
                    Learn More
                </a>
            )}
        </div>
    )
};


const EventsPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold text-on-surface mb-2">Global Events</h1>
        <p className="text-on-surface-variant max-w-2xl mx-auto">Stay connected with major events happening across the entire Church of God Mission International family.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {GLOBAL_EVENTS_DATA.map(event => (
          <EventCard key={event.id} event={event} />
        ))}
      </div>
    </div>
  );
};

export default EventsPage;