import React, { useState, useMemo } from 'react';
import { ZONES_DATA } from '../constants';
import { ZoneData } from '../types';
import ZoneCard from '../components/ZoneCard';

interface DirectoryPageProps {
  onSelectZone: (zone: ZoneData) => void;
}

const DirectorySection: React.FC<{ title: string; zones: ZoneData[]; onSelectZone: (zone: ZoneData) => void }> = ({ title, zones, onSelectZone }) => (
  <section className="mb-12">
    <h2 className="text-2xl font-bold text-primary mb-6 border-l-4 border-primary pl-4">{title}</h2>
    {zones.length > 0 ? (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {zones.map(zone => (
          <ZoneCard key={zone.id} zone={zone} onSelect={() => onSelectZone(zone)} />
        ))}
      </div>
    ) : (
      <p className="text-on-surface-variant">No outposts found matching your criteria.</p>
    )}
  </section>
);

const DirectoryPage: React.FC<DirectoryPageProps> = ({ onSelectZone }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const { bishopricZones, zonalOutposts } = useMemo(() => {
    const filtered = ZONES_DATA.filter(zone =>
      zone.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      zone.leader.toLowerCase().includes(searchTerm.toLowerCase()) ||
      zone.location.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return filtered.reduce<{ bishopricZones: ZoneData[], zonalOutposts: ZoneData[] }>((acc, zone) => {
      if (zone.name.toLowerCase().includes('bishopric')) {
        acc.bishopricZones.push(zone);
      } else {
        acc.zonalOutposts.push(zone);
      }
      return acc;
    }, { bishopricZones: [], zonalOutposts: [] });

  }, [searchTerm]);

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-on-surface mb-2">Operations Directory</h1>
        <p className="text-on-surface-variant">Locate and establish contact with command centers and outposts.</p>
      </div>

      <div className="sticky top-[72px] z-20 py-4 bg-surface">
        <div className="relative">
           <span className="material-symbols-outlined absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant">search</span>
           <input
             type="text"
             placeholder="Search by designation, coordinator, or location..."
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full p-4 pl-12 bg-surface-container border border-outline rounded-lg text-on-surface placeholder-on-surface-variant focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
           />
        </div>
      </div>

      <div className="mt-8">
        <DirectorySection title="Bishopric Command" zones={bishopricZones} onSelectZone={onSelectZone} />
        <DirectorySection title="Zonal Outposts" zones={zonalOutposts} onSelectZone={onSelectZone} />
      </div>
    </div>
  );
};

export default DirectoryPage;