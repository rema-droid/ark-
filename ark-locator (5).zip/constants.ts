import { ZoneData, GlobalEvent, Sermon, UserProfile } from './types';

export const GLOBE_RADIUS = 100;

const generateEvents = (zoneId: string): { id: string; title: string; date: string; time: string; }[] => [
    { id: `evt-${zoneId}-1`, title: 'Sunday Worship Service', date: 'Every Sunday', time: '9:00 AM' },
    { id: `evt-${zoneId}-2`, title: 'Mid-week Bible Study', date: 'Every Wednesday', time: '6:00 PM' },
    { id: `evt-${zoneId}-3`, title: 'Youth Fellowship', date: 'Every Friday', time: '5:00 PM' },
];

const generateUserCount = () => Math.floor(Math.random() * (3500 - 300 + 1)) + 300;

export const GLOBAL_EVENTS_DATA: GlobalEvent[] = [
    {
        id: 'global-1',
        title: 'CGMi Annual International Convention',
        date: 'November 5-12, 2024',
        type: 'Conference',
        description: 'Join believers from around the world for a week of powerful teaching, worship, and fellowship at Faith Arena, Benin City.',
        link: '#'
    },
    {
        id: 'global-2',
        title: 'Archbishop\'s Global Prayer Livestream',
        date: 'First Saturday of every month',
        type: 'Livestream',
        description: 'Connect with Archbishop M.E. Benson Idahosa for a special time of prayer and impartation, streamed live on all our platforms.',
        link: '#'
    },
    {
        id: 'global-3',
        title: 'Global Missions Emphasis Week',
        date: 'October 1-7, 2024',
        type: 'Special Service',
        description: 'A dedicated week to highlight and support our global mission projects. Special services will be held in all zones worldwide.',
    },
    {
        id: 'global-4',
        title: 'Next-Gen Leaders Summit',
        date: 'September 15-17, 2024',
        type: 'Conference',
        description: 'A dynamic summit for young leaders and professionals across the ministry, focusing on innovation, leadership, and spiritual growth.',
    }
];

export const SERMONS_DATA: Sermon[] = [
    {
        id: 'sermon-1',
        title: 'The Power of Faith',
        speaker: 'Archbishop M.E. Benson Idahosa',
        date: '2024-07-21',
        thumbnailUrl: 'https://images.unsplash.com/photo-1504229618473-9da54355523f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    },
    {
        id: 'sermon-2',
        title: 'Walking in Dominion',
        speaker: 'Bishop Feb Idahosa',
        date: '2024-07-14',
        thumbnailUrl: 'https://images.unsplash.com/photo-1582983758332-95e2d7335123?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    },
    {
        id: 'sermon-3',
        title: 'Understanding the Anointing',
        speaker: 'Rev. Tari Hudson Ekiyor',
        date: '2024-07-07',
        thumbnailUrl: 'https://images.unsplash.com/photo-1594744839849-559e210141d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    },
    {
        id: 'sermon-4',
        title: 'Faith for the Supernatural',
        speaker: 'Bishop Wale Ajayi',
        date: '2024-06-30',
        thumbnailUrl: 'https://images.unsplash.com/photo-1604163982439-6a33de48a032?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    },
    {
        id: 'sermon-5',
        title: 'The Heart of a Leader',
        speaker: 'Bishop Curtis Fianu',
        date: '2024-06-23',
        thumbnailUrl: 'https://images.unsplash.com/photo-1558449479-7f3e69775438?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    },
    {
        id: 'sermon-6',
        title: 'Global Missions Mandate',
        speaker: 'Rev. Dr. Osadolor Asemota',
        date: '2024-06-16',
        thumbnailUrl: 'https://images.unsplash.com/photo-1569429454477-16e0310c184c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60',
        videoUrl: '#'
    }
];


export const MOCK_USER_PROFILE: UserProfile = {
    id: 'agent-001',
    name: 'Faithful Agent',
    email: 'agent@cgmglobal.org',
    zoneAffiliation: 'BISHOPRIC - FAITH ARENA',
    imageUrl: 'https://images.unsplash.com/photo-1582510092147-32064010b54f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=400&q=80',
    titheHistory: [
        { id: 't-1', date: '2024-07-01', amount: 250, zone: 'BISHOPRIC - FAITH ARENA' },
        { id: 't-2', date: '2024-06-01', amount: 250, zone: 'BISHOPRIC - FAITH ARENA' },
        { id: 't-3', date: '2024-05-01', amount: 200, zone: 'BISHOPRIC - FAITH ARENA' },
        { id: 't-4', date: '2024-04-01', amount: 220, zone: 'BISHOPRIC - FAITH ARENA' }
    ]
}


export const ZONES_DATA: ZoneData[] = [
  { id: '1', name: 'ABRAKA ZONE', leader: 'REV ANIEKAN UDOH', phone: '8037255579', location: 'Abraka, Nigeria', userCount: generateUserCount(), events: generateEvents('1'), lat: 5.79, lon: 6.10, region: 'Nigeria - South South' },
  { id: '2', name: 'AGBARO DELTA STATE ZONE', leader: 'REV EMMANUEL AZIAKPONO', phone: '8037198984', location: 'Agbaro, Nigeria', userCount: generateUserCount(), events: generateEvents('2'), lat: 5.53, lon: 5.86, region: 'Nigeria - South South' },
  { id: '3', name: 'ASABA ZONE 2', leader: 'REV EMMANUEL ETUK', phone: '8023523583', location: 'Asaba, Nigeria', userCount: generateUserCount(), events: generateEvents('3'), lat: 6.19, lon: 6.72, region: 'Nigeria - South South' },
  { id: '4', name: 'ASIA ZONE (JAPAN)', leader: 'REV KENNY EVANS', phone: '81-9034398325', location: 'Tokyo, Japan', userCount: generateUserCount(), events: generateEvents('4'), lat: 35.68, lon: 139.69, region: 'Asia' },
  { id: '5', name: 'ASIA ZONE 2 (MALAYSIA)', leader: 'REV SUNDAY BELLO', phone: '60162578895', location: 'Kuala Lumpur, Malaysia', userCount: generateUserCount(), events: generateEvents('5'), lat: 3.13, lon: 101.68, region: 'Asia' },
  { id: '6', name: 'BAYELSA ZONE', leader: 'REV MATTHEW OSADEBE', phone: '8034052786', location: 'Yenagoa, Nigeria', userCount: generateUserCount(), events: generateEvents('6'), lat: 4.92, lon: 6.26, region: 'Nigeria - South South' },
  { id: '7', name: 'BENIN ZONE 4', leader: 'REV MRS. OLAYINKA AKEN\'OVA', phone: '8023370924', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('7'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '8', name: 'BENIN ZONE 5', leader: 'REV OSAS OBARISIAGBON', phone: '8076767655', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('8'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '9', name: 'BENIN ZONE 6', leader: 'REV PROV MARTINS AISIEN', phone: '7038818640', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('9'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '10', name: 'BENIN ZONE 7', leader: 'REV MONDAY IGBINOBARO', phone: '8029988910', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('10'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '11', name: 'BENIN ZONE 8', leader: 'REV DENNIS ISIAKPONA', phone: '8023157279', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('11'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '12', name: 'BENIN ZONE 9', leader: 'REV MRS ESTHER UDIA', phone: '8033945406', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('12'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '13', name: 'BENUE ZONE', leader: 'REV SAMUEL T. HAGHER', phone: '8029862918', location: 'Makurdi, Nigeria', userCount: generateUserCount(), events: generateEvents('13'), lat: 7.73, lon: 8.53, region: 'Nigeria - North Central' },
  { id: '14', name: 'BISHOPRIC - ABA', leader: 'REV DANIEL KALU', phone: '8036054631', location: 'Aba, Nigeria', userCount: generateUserCount(), events: generateEvents('14'), lat: 5.11, lon: 7.36, region: 'Nigeria - South East' },
  { id: '15', name: 'BISHOPRIC - ABUJA', leader: 'BISHOP DR. FESTUS AKHIMIEN', phone: '8033835640', location: 'Abuja, Nigeria', userCount: generateUserCount(), events: generateEvents('15'), lat: 9.07, lon: 7.49, region: 'Nigeria - North Central' },
  { id: '16', name: 'BISHOPRIC - AKWA - IBOM', leader: 'REV SHADRACK O. CHARLES', phone: '8035506914', location: 'Uyo, Nigeria', userCount: generateUserCount(), events: generateEvents('16'), lat: 5.05, lon: 7.93, region: 'Nigeria - South South' },
  { id: '17', name: 'BISHOPRIC - ANOMA', leader: 'REV FESTUS S. OBASA', phone: '8033658282', location: 'Anoma, Nigeria', userCount: generateUserCount(), events: generateEvents('17'), lat: 5.48, lon: 7.02, region: 'Nigeria - South East' }, // Assuming ANOMA is near Owerri
  { id: '18', name: 'BISHOPRIC - ASABA 1', leader: 'REV ERIC NWACHUKWU', phone: '8032360142', location: 'Asaba, Nigeria', userCount: generateUserCount(), events: generateEvents('18'), lat: 6.19, lon: 6.72, region: 'Nigeria - South South' },
  { id: '19', name: 'BISHOPRIC - BAYELSA', leader: 'REV ALEXANDER INEGBESE', phone: '8034547043', location: 'Yenagoa, Nigeria', userCount: generateUserCount(), events: generateEvents('19'), lat: 4.92, lon: 6.26, region: 'Nigeria - South South' },
  { id: '20', name: 'BISHOPRIC - BORIKIRI', leader: 'BISHOP MARTINS PELEMO', phone: '8032448919', location: 'Borikiri, Nigeria', userCount: generateUserCount(), events: generateEvents('20'), lat: 4.75, lon: 7.01, region: 'Nigeria - South South' },
  { id: '21', name: 'BISHOPRIC - CROSS RIVER', leader: 'REV BARR. CHRIS EKPANG', phone: '8037114668', location: 'Calabar, Nigeria', userCount: generateUserCount(), events: generateEvents('21'), lat: 4.95, lon: 8.32, region: 'Nigeria - South South' },
  { id: '22', name: 'BISHOPRIC - DIOBU', leader: 'REV BOMA GEORGE', phone: '8101387240', location: 'Diobu, Nigeria', userCount: generateUserCount(), events: generateEvents('22'), lat: 4.78, lon: 6.98, region: 'Nigeria - South South' },
  { id: '23', name: 'BISHOPRIC - EKENHUAN', leader: 'BISHOP DICKSON ETIOSA-OGBAHON', phone: '8056404818', location: 'Ekenhuan, Nigeria', userCount: generateUserCount(), events: generateEvents('23'), lat: 6.25, lon: 5.55, region: 'Nigeria - South South' },
  { id: '24', name: 'BISHOPRIC - ESAN', leader: 'REV SUNDAY OMON EIGBADON', phone: '8052724850', location: 'Esan, Nigeria', userCount: generateUserCount(), events: generateEvents('24'), lat: 6.66, lon: 6.37, region: 'Nigeria - South South' },
  { id: '25', name: 'BISHOPRIC - FAITH ARENA', leader: 'BISHOP FEB IDAHOSA', phone: '8023225064', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('25'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '26', name: 'BISHOPRIC - GLOBAL', leader: 'REV TARI HUDSON EKIYOR', phone: '8034485317', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('26'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '27', name: 'BISHOPRIC - IGUODEYALA', leader: 'REV DR. OSADOLOR ASEMOTA', phone: '8023298992', location: 'Iguodeyala, Nigeria', userCount: generateUserCount(), events: generateEvents('27'), lat: 6.30, lon: 5.70, region: 'Nigeria - South South' },
  { id: '28', name: 'BISHOPRIC - IKPOBA HILL', leader: 'BISHOP MOSES OSAYOMWOBOR', phone: '7062229719', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('28'), lat: 6.33, lon: 5.65, region: 'Nigeria - South South' },
  { id: '29', name: 'BISHOPRIC - KUBWA FCT', leader: 'REV OLUSUJI ADEBOWALE', phone: '8039291970', location: 'Kubwa, Abuja, Nigeria', userCount: generateUserCount(), events: generateEvents('29'), lat: 9.15, lon: 7.33, region: 'Nigeria - North Central' },
  { id: '30', name: 'BISHOPRIC - LAGOS', leader: 'BISHOP CURTIS FIANU', phone: '8034049578', location: 'Lagos, Nigeria', userCount: generateUserCount(), events: generateEvents('30'), lat: 6.52, lon: 3.37, region: 'Nigeria - South West' },
  { id: '31', name: 'BISHOPRIC - LAGOS CENTRAL', leader: 'REV MARK SOLOMON', phone: '8177035777', location: 'Lagos, Nigeria', userCount: generateUserCount(), events: generateEvents('31'), lat: 6.52, lon: 3.37, region: 'Nigeria - South West' },
  { id: '32', name: 'BISHOPRIC - LAGOS WEST', leader: 'BISHOP SUNNY ATTAH', phone: '8033218270', location: 'Lagos, Nigeria', userCount: generateUserCount(), events: generateEvents('32'), lat: 6.52, lon: 3.37, region: 'Nigeria - South West' },
  { id: '33', name: 'BISHOPRIC - MIRACLE CENTRE', leader: 'BISHOP WALE AJAYI', phone: '8033546579', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('33'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '34', name: 'BISHOPRIC - MOTHER CHURCH IYARO', leader: 'BISHOP MATTHEW EGWOWA', phone: '8033274311', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('34'), lat: 6.34, lon: 5.62, region: 'Nigeria - South South' },
  { id: '35', name: 'BISHOPRIC - NDOKWA', leader: 'REV GODSON ELKANAH', phone: '8062839931', location: 'Ndokwa, Nigeria', userCount: generateUserCount(), events: generateEvents('35'), lat: 5.72, lon: 6.43, region: 'Nigeria - South South' },
  { id: '36', name: 'BISHOPRIC - NEW WARRI', leader: 'BISHOP ASUQUO AKPAN-EKPO', phone: '8023312033', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('36'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' },
  { id: '37', name: 'BISHOPRIC - NORTH AMERICA', leader: 'BISHOP KINGSLEY EWANSIHA', phone: '009-2147707392', location: 'Dallas, USA', userCount: generateUserCount(), events: generateEvents('37'), lat: 32.77, lon: -96.79, region: 'North America' },
  { id: '38', name: 'BISHOPRIC - NORTH EAST, JOS', leader: 'REV GODWIN C. OBI', phone: '8033785652', location: 'Jos, Nigeria', userCount: generateUserCount(), events: generateEvents('38'), lat: 9.93, lon: 8.89, region: 'Nigeria - North Central' },
  { id: '39', name: 'BISHOPRIC - WARRI SOUTH', leader: 'REV SANI MIRACLE GADZAMA', phone: '8036606959', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('39'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' },
  { id: '40', name: 'BISHOPRIC - WOJI', leader: 'BISHOP SUNNY UGBAH', phone: '8035777007', location: 'Woji, Nigeria', userCount: generateUserCount(), events: generateEvents('40'), lat: 4.82, lon: 7.04, region: 'Nigeria - South South' },
  { id: '41', name: 'BOMADI ZONE', leader: 'REV SYLVESTER OWEIBE', phone: '8035799480', location: 'Bomadi, Nigeria', userCount: generateUserCount(), events: generateEvents('41'), lat: 5.16, lon: 5.51, region: 'Nigeria - South South' },
  { id: '42', name: 'BURUNDI ZONE', leader: 'AHMED CHRISTIAN', phone: '8035426533', location: 'Bujumbura, Burundi', userCount: generateUserCount(), events: generateEvents('42'), lat: -3.38, lon: 29.36, region: 'Africa' },
  { id: '43', name: 'DELTA RIVERINE ZONE', leader: 'REV JOHN OFUNAMA', phone: '8052725006', location: 'Delta Riverine, Nigeria', userCount: generateUserCount(), events: generateEvents('43'), lat: 5.36, lon: 5.25, region: 'Nigeria - South South' },
  { id: '44', name: 'EDO NORTH ZONE 1', leader: 'REV EMMANUEL AMADIN', phone: '8039269897', location: 'Edo North, Nigeria', userCount: generateUserCount(), events: generateEvents('44'), lat: 7.06, lon: 6.26, region: 'Nigeria - South South' },
  { id: '45', name: 'EDO NORTH ZONE 2', leader: 'REV MICHEAL. OK MARTINS', phone: '8037969207', location: 'Edo North, Nigeria', userCount: generateUserCount(), events: generateEvents('45'), lat: 7.06, lon: 6.26, region: 'Nigeria - South South' },
  { id: '46', name: 'EDO NORTH ZONE 3', leader: 'REV E.S. AGBARAJO', phone: '9079842370', location: 'Edo North, Nigeria', userCount: generateUserCount(), events: generateEvents('46'), lat: 7.06, lon: 6.26, region: 'Nigeria - South South' },
  { id: '47', name: 'ENUGU ZONE', leader: 'REV. ERNEST ABADI', phone: '8035994150', location: 'Enugu, Nigeria', userCount: generateUserCount(), events: generateEvents('47'), lat: 6.44, lon: 7.5, region: 'Nigeria - South East' },
  { id: '48', name: 'ESAN ZONE 2', leader: 'REV DAVID EMODE', phone: '8106434746', location: 'Esan, Nigeria', userCount: generateUserCount(), events: generateEvents('48'), lat: 6.71, lon: 6.45, region: 'Nigeria - South South' },
  { id: '49', name: 'EUROPE OUTSIDE UK', leader: 'REV EMEM ESENAM', phone: '009-447723000278', location: 'Europe', userCount: generateUserCount(), events: generateEvents('49'), lat: 50.85, lon: 4.35, region: 'Europe' },
  { id: '50', name: 'IKA ZONE 2', leader: 'REV DONATUS GHEGHOR', phone: '8034506049', location: 'Ika, Nigeria', userCount: generateUserCount(), events: generateEvents('50'), lat: 6.25, lon: 6.19, region: 'Nigeria - South South' },
  { id: '51', name: 'ISOKO ZONE', leader: 'REV ERNEST EZEWU OBARO', phone: '8101383778', location: 'Isoko, Nigeria', userCount: generateUserCount(), events: generateEvents('51'), lat: 5.47, lon: 6.21, region: 'Nigeria - South South' },
  { id: '52', name: 'KANO ZONE', leader: 'REV MATTHEW ATCHOR', phone: '8023261381', location: 'Kano, Nigeria', userCount: generateUserCount(), events: generateEvents('52'), lat: 12.00, lon: 8.51, region: 'Nigeria - North West' },
  { id: '53', name: 'LAGOS EAST ZONE', leader: 'REV MACWEN AKHAGHEMHE LAMAI', phone: '8022241355', location: 'Lagos, Nigeria', userCount: generateUserCount(), events: generateEvents('53'), lat: 6.60, lon: 3.35, region: 'Nigeria - South West' },
  { id: '54', name: 'NEW EKET ZONE', leader: 'REV JOHN ODUBELE', phone: '7080707470', location: 'New Eket, Nigeria', userCount: generateUserCount(), events: generateEvents('54'), lat: 4.64, lon: 7.92, region: 'Nigeria - South South' },
  { id: '55', name: 'NKPOLU RUMUIGBO ZONE', leader: 'REV PHILIP UGIAGBE', phone: '7032293155', location: 'Nkpolu Rumuigbo, Nigeria', userCount: generateUserCount(), events: generateEvents('55'), lat: 4.84, lon: 6.99, region: 'Nigeria - South South' },
  { id: '56', name: 'NORTH EAST ZONE 2', leader: 'REV PAUL OSHIOBUGIE', phone: '8067363121', location: 'North East, Nigeria', userCount: generateUserCount(), events: generateEvents('56'), lat: 11.83, lon: 13.15, region: 'Nigeria - North East' },
  { id: '57', name: 'OKIRIKA ZONE', leader: 'REV OTONYE R. DAKA', phone: '8187591942', location: 'Okirika, Nigeria', userCount: generateUserCount(), events: generateEvents('57'), lat: 4.74, lon: 7.08, region: 'Nigeria - South South' },
  { id: '58', name: 'OMOKU ZONE', leader: 'REV EMMANUEL PATRICK UNDIE', phone: '9037712266', location: 'Omoku, Nigeria', userCount: generateUserCount(), events: generateEvents('58'), lat: 5.34, lon: 6.65, region: 'Nigeria - South South' },
  { id: '59', name: 'OWAN ZONE 1', leader: 'REV LUKE IDAGHE', phone: '8034883488', location: 'Owan, Nigeria', userCount: generateUserCount(), events: generateEvents('59'), lat: 6.92, lon: 6.14, region: 'Nigeria - South South' },
  { id: '60', name: 'OWAN ZONE 2', leader: 'REV REUBEN EKWUASE', phone: '7032473323', location: 'Owan, Nigeria', userCount: generateUserCount(), events: generateEvents('60'), lat: 6.81, lon: 6.19, region: 'Nigeria - South South' },
  { id: '61', name: 'OWERRI ZONE', leader: 'REV PROF. IYKE J.D. NWOSU', phone: '8033273947', location: 'Owerri, Nigeria', userCount: generateUserCount(), events: generateEvents('61'), lat: 5.48, lon: 7.02, region: 'Nigeria - South East' },
  { id: '62', name: 'RUMUOMASI ZONE', leader: 'REV MAGNUS ESUIKUP', phone: '8033427206', location: 'Rumuomasi, Nigeria', userCount: generateUserCount(), events: generateEvents('62'), lat: 4.82, lon: 7.02, region: 'Nigeria - South South' },
  { id: '63', name: 'SAPELE ZONE 1', leader: 'REV WILLIAMS IKOKO', phone: '8034740296', location: 'Sapele, Nigeria', userCount: generateUserCount(), events: generateEvents('63'), lat: 5.89, lon: 5.67, region: 'Nigeria - South South' },
  { id: '64', name: 'SAPELE ZONE 2', leader: 'REV AUGUSTINE AGANMWONYI', phone: '8131993751', location: 'Sapele, Nigeria', userCount: generateUserCount(), events: generateEvents('64'), lat: 5.89, lon: 5.67, region: 'Nigeria - South South' },
  { id: '65', name: 'UGHELLI ZONE', leader: 'REV BAMIDELE SOYEMI', phone: '8184715139', location: 'Ughelli, Nigeria', userCount: generateUserCount(), events: generateEvents('65'), lat: 5.49, lon: 6.00, region: 'Nigeria - South South' },
  { id: '66', name: 'UNITED KINGDOM ZONE', leader: 'REV OBINNA MADUNAGU', phone: '009-447961648094', location: 'London, United Kingdom', userCount: generateUserCount(), events: generateEvents('66'), lat: 51.50, lon: -0.12, region: 'Europe' },
  { id: '67', name: 'VICTORIA ISLAND ZONE', leader: 'REV CHRISTOPHER UBAMADU', phone: '8055451657', location: 'Victoria Island, Lagos, Nigeria', userCount: generateUserCount(), events: generateEvents('67'), lat: 6.42, lon: 3.42, region: 'Nigeria - South West' },
  { id: '68', name: 'WARRI ZONE 1', leader: 'REV EMMANUEL AMEH', phone: '8033607226', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('68'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' },
  { id: '69', name: 'WARRI ZONE 3', leader: 'REV EVANS OBAKPOLOR', phone: '8033886593', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('69'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' },
  { id: '70', name: 'WARRI ZONE 4', leader: 'REV EMMANUEL OBHIEMHIN', phone: '8063383607', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('70'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' },
  { id: '71', name: 'WESTERN ZONE 1', leader: 'REV MRS. CATHY LASAKI', phone: '8064945676', location: 'Western Nigeria', userCount: generateUserCount(), events: generateEvents('71'), lat: 7.37, lon: 3.94, region: 'Nigeria - South West' },
  { id: '72', name: 'WESTERN ZONE 2', leader: 'REV GODFREY IMHANWA', phone: '8062360750', location: 'Western Nigeria', userCount: generateUserCount(), events: generateEvents('72'), lat: 7.37, lon: 3.94, region: 'Nigeria - South West' },
  { id: '73', name: 'GLOBAL OFFICE', leader: 'REV EGHOSA IGUMBOR', phone: '8023446240', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('73'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '74', name: 'GLOBAL OFFICE', leader: 'REV ALEX IDUH', phone: '8055273550', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('74'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '75', name: 'GLOBAL OFFICE', leader: 'REV MRS. MAUREEN OKORO-SOKOH', phone: '8033230014', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('75'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '76', name: 'GLOBAL OFFICE', leader: 'REV EKHATOR OSAYANDE', phone: '8056013874', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('76'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '77', 'name': 'GLOBAL OFFICE', leader: 'REV ENGR. EMMANUEL EGBAGBE', phone: '8023014590', location: 'Benin City, Nigeria', userCount: generateUserCount(), events: generateEvents('77'), lat: 6.33, lon: 5.62, region: 'Nigeria - South South' },
  { id: '78', name: 'WARRI ZONE 3 OUTGOING', leader: 'REV DR. JONATHAN IDIALU', phone: '8037180441', location: 'Warri, Nigeria', userCount: generateUserCount(), events: generateEvents('78'), lat: 5.51, lon: 5.74, region: 'Nigeria - South South' }
];